<?php


use App\Http\Controllers\API\ClientController;
use App\Http\Controllers\API\CreditController;
use App\Http\Controllers\API\ExchangeController;
use App\Http\Controllers\API\SavingController;
use App\Http\Controllers\API\TaxController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//Route::middleware('auth:api')->get('/user', function (Request $request) {
//    return $request->user();
//});

route::get('saving',[SavingController::class, 'index']);
route::get('flexSaving',[SavingController::class, 'get_flex']);
route::post('ahorro-flex/tasa',[SavingController::class, 'actualizar_tasa_flex']);
route::get('dpfSaving',[SavingController::class, 'get_dpf']);
route::post('deposito-plazo-fijo/tasa',[SavingController::class, 'actualizar_tasa_dpf']);
route::post('client',[ClientController::class,'store']);
route::get('proSavingsPlan',[SavingController::class, 'get_proPlan']);
route::post('career',[SavingController::class,'save_career']);

route::get('credits',[CreditController::class,'index']);
route::get('creditoEducativo',[CreditController::class,'get_educativo']);
route::get('creditoInversion',[CreditController::class,'get_inversion']);
route::post('credito-inversion/tasa',[CreditController::class,'actualizar_tasa_credito_inversion']);
route::get('creditoInmobiliario',[CreditController::class,'get_inmobiliario']);
route::post('credito-vivienda/tasa',[CreditController::class,'actualizar_tasa_credito_vivienda']);
//PRUEBA

route::get('tasas-cambio',[ExchangeController::class, 'obtener_tasas']);
route::post('tasas-cambio',[ExchangeController::class, 'guardar_tasas']);

Route::prefix('tax')->group(function () {
    Route::get('/',[ TaxController::class, 'getAll']);
    Route::post('/',[ TaxController::class, 'create']);
    Route::delete('/{id}',[ TaxController::class, 'delete']);
    Route::get('/{id}',[ TaxController::class, 'get']);
    Route::put('/{id}',[ TaxController::class, 'update']);
});
